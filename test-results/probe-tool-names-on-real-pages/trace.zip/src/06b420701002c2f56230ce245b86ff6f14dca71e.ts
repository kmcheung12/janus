import { expect, test } from '@playwright/test'
import { startDaemon } from './fixtures/daemon'
import { launchNativeChrome } from './fixtures/chrome-native'
import { connectMcp } from './fixtures/mcp'

/** Diagnostic lane: tool names on real pages, not fixtures. */
const TARGETS = (process.env.JANUS_PROBE_TARGET ?? [
  'https://news.ycombinator.com/',
  'https://en.wikipedia.org/wiki/Ada_Lovelace',
  'https://developer.mozilla.org/en-US/',
  'https://www.bbc.co.uk/news',
].join(',')).split(',')

test('tool names on real pages', async () => {
  test.setTimeout(300_000)
  const daemon = await startDaemon()
  const chrome = await launchNativeChrome()

  try {
    const first = await chrome.context.newPage()
    await first.goto(TARGETS[0], { waitUntil: 'domcontentloaded' })
    await first.waitForTimeout(1500)

    const [worker] = chrome.context.serviceWorkers().length
      ? chrome.context.serviceWorkers()
      : [await chrome.context.waitForEvent('serviceworker', { timeout: 30_000 })]
    const extensionId = new URL(worker.url()).host

    const settings = await chrome.context.newPage()
    await settings.goto(`chrome-extension://${extensionId}/settings.html`)
    await settings.getByRole('button', { name: 'Browser connection' }).click()
    await settings.locator('input[type="text"]').first().fill(new URL(daemon.mcpUrl).origin)
    await settings.getByRole('button', { name: 'Pair with Janus' }).click()
    await settings.getByText('Connected').waitFor({ timeout: 20_000 })

    const agentToken = await settings.evaluate(() => {
      const code = document.querySelector('.handoff code')?.textContent ?? ''
      return code.match(/Bearer ([0-9a-f]{64})/)?.[1] ?? ''
    })
    const client = await connectMcp(daemon.mcpUrl, agentToken)

    for (const target of TARGETS) {
      const page = target === TARGETS[0] ? first : await chrome.context.newPage()
      if (page !== first) {
        await page.goto(target, { waitUntil: 'domcontentloaded' }).catch(() => {})
        await page.waitForTimeout(2000)
      }

      await settings.evaluate(async (url) => {
        const tabs = await chrome.tabs.query({ currentWindow: true })
        const tab = tabs.find((t) => t.url === url)
        if (!tab?.id) return
        await chrome.runtime.sendMessage({ type: 'JANUS_BT_ENABLE_PAGE', tabId: tab.id })
        await chrome.runtime.sendMessage({ type: 'JANUS_BT_SET_AUTO_WRITES', tabId: tab.id, allow: true })
      }, page.url())

      const raw = JSON.parse((await client.call('list_pages', {})).text) as unknown
      const pages = (Array.isArray(raw) ? raw : []) as Array<{ pageId: string; url: string }>
      const entry = pages.find((p) => p.url === page.url())
      if (!entry) { console.log(`\n═══ ${target}\n  (not enabled)`); continue }

      const listed = JSON.parse((await client.call('list_page_tools', { pageId: entry.pageId })).text) as {
        tools: Array<{ name: string; readOnlyHint: boolean; inputSchema: { properties?: Record<string, unknown> } }>
      }

      console.log(`\n═══ ${new URL(target).hostname}`)
      for (const tool of listed.tools.filter((t) => !t.readOnlyHint)) {
        console.log(`  ${tool.name}(${Object.keys(tool.inputSchema?.properties ?? {}).join(', ')})`)
      }
      if (!listed.tools.some((t) => !t.readOnlyHint)) console.log('  (no form tools)')
    }

    await client.close().catch(() => {})
    expect(true).toBe(true)
  } finally {
    await chrome.stop()
    await daemon.stop()
  }
})
